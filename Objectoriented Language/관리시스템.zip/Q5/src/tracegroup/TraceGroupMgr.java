package tracegroup;

import java.util.Scanner;

import member.Contact;
import member.ContactMgr;

public class TraceGroupMgr {
	int index;
	TraceGroup tgList[];
	Scanner scan;

	public TraceGroupMgr(int n) {
		// TODO Auto-generated constructor stub
		index = 0;
		tgList = new TraceGroup[n];
		scan = new Scanner(System.in);
	}

	public void init(ContactMgr cm) {
		 
	}

	public void addTraceGroup(ContactMgr cm) {
		int id;
		Contact c = null;
		TraceGroup t = null;
		id = index + 3;
		System.out.println("id: ");
		System.out.println(id);
		cm.ShowAll();
		System.out.println("Ȯ���� �̸�: ");
		String name = scan.next();
		c = cm.Find(name);
		if (c == null) {
			System.out.println("reagain");
		} else {
			t = new TraceGroup(id, c);
			tgList[index++] = t;
			System.out.println("sucessful");
		}
	}
	

	public void ShowAll() {
		for (int i = 0; i < index; i++) {
			tgList[i].ShowData();
		}
	}
}
