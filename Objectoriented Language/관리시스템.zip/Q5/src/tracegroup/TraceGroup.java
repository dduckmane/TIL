package tracegroup;

import java.util.Scanner;

import member.*;
import show.Showable;

public class TraceGroup implements Showable{
	int id;
	Contact confirmed;
	Contact candidates[];
	int index;
	public TraceGroup(int id,Contact confirmed) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.confirmed=confirmed;
		index=0;
	}
	@Override
	public void ShowData() {
		// TODO Auto-generated method stub
		System.out.println(id+"\t"+confirmed.getName()+"\t"+index);
	}

}
