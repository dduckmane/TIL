package member;

public class ContactMgr {

}
